//LAB 3 - ARRAYS & LOOPS - PART 1


//ARRAY OF FRUITS
var fruits = ['Apple', 'Banana', 'Cherry', 'Date', 'Blueberry'];


//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX
alert(fruits[0]); // This will alert 'Apple'